#!/usr/bin/python
# -*- coding: utf-8 -*-
enable = False
format = 'Bdc'
description = 'Babylon (bdc)'
extentions = ('.bdc')
readOptions = ()
writeOptions = ()

