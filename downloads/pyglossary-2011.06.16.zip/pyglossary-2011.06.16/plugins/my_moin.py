enable = True
format = 'moin'
description = 'Moin (txt)'
extentions = ('.txt',)
readOptions = ()
writeOptions = ()

import sys, os, re, shutil
sys.path.append('/usr/share/pyglossary/src')
#from text_utils import *

def read(glos, filename):
    pass




