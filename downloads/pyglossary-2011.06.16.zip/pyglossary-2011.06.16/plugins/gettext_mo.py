#!/usr/bin/python
# -*- coding: utf-8 -*-

from formats_common import *

enable = False
format = 'GettextMo'
description = 'Gettext Binary (mo)'
extentions = ('.mo',)
readOptions = ()
writeOptions = ()


