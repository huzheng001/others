#!/bin/sh
python "`dirname \"$0\"`/src/pyglossary.pyw" "$@"

