# Copyright (C) 2004-2005 Laurent Sansonetti

# Removing the data/locale directory
require 'fileutils'
FileUtils.rm_rf('locale')